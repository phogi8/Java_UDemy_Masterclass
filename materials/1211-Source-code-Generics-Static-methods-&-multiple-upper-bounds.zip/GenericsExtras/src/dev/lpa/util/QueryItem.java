package dev.lpa.util;

public interface QueryItem {

    public boolean matchFieldValue(String fieldName, String value);
}
