package dev.lpa.domain;

public record Employee(String first, String last, String hireDate) {
}
